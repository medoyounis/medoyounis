//Mohammed Younis && Daniel Linn
import java.util.InputMismatchException;
import java.util.Scanner;

/*Project 1 solution
 * 
 * This code is a collaboration between:
 * 
 * Daniel Linn U00516701
 * Mohammed Younis U00575660
 * 
 */

public class GoFish {

	private Deck deck;
	private Player[] players;
	private Scanner s = new Scanner(System.in);
	int deckleft; //to keep track of cards in the deck
	
	public GoFish() {
		startGame();
		deal();
		deckleft= (52 - 5 * players.length); //number of card left in the deck
	}
	
	public void startGame() {        //start game method
		System.out.println("Enter the number of players 2-6: ");
		int playerNumber = s.nextInt();
		s.nextLine();
		if(playerNumber > 1 && playerNumber < 7) {
			Player[] players = new Player[playerNumber];
			this.players = players;
			for(int i= 0; i< players.length; i++) {
				System.out.println("What's your name?");
				String name = s.nextLine();
				players[i] = new Player();
				players[i].name = name;
			}
		} else {
			System.out.println("Must be a number between 2 and 6");
			startGame();
		}
		deck = new Deck();
		deck.shuffle();
	}
	
	public void deal() {
		for(int i= 0; i< players.length; i++) {
			for(int j= 0; j< 5; j++) {
				players[i].drawCard(deck);
			}
		}
	}
	
	public void printHand(Player p) {
		System.out.println("");
		System.out.println(p.name + "'s turn: \nYour Cards are:");
		System.out.println("1||2||3||4||5||6||7||8||9|10|11|12|13");
		for(int i= 0; i< 13; i++) {
			System.out.print(p.hand[i] + ", ");
		}
		System.out.println("\n" + p.numCards);
	}
	
	public boolean isInHand(Player p, int c) {
		if (p.hand[c-1] > 0)
			return true;
		else
			return false;
	}
	
	public boolean isValidCard(Player p, int input) {
		if(input >= 1 && input <= 13)
			if(isInHand(p, input) == true)
				return true;
			else
				return false;
		else
			return false;
	}
	
	
	public String winner() { // to decide who is the winner
		int p= 0;
		String toReturn = "Game Over. Winner(s): ";
		Player winners[] = new Player[players.length];
		for(int i= 1; i< players.length; i++){
			if(players[p].books == players[i].books){
				winners[i] = players[i]; 
			}
			if(players[p].books < players[i].books){
				p= i;
			}
		}
		winners[p] = players[p];
		int count = 0;
		for(int j=0; j<winners.length; j++){
			if(winners[j] != null){
				if(winners[j].books == winners[p].books) {
					toReturn += winners[j];
					count++;
				}	
			}
		}
		if (count >1)	{
			System.out.println("It's a tie!");
			return toReturn;
		}
		return toReturn;
	}
	
	public void turn(int asker) {     //the turn method    where asker is the one who is asking, asked is the one being asked 
		int asked = 0;
		int temp = 1;
		int card = 99;
		int count = 0;
		
		do {
			//System.out.println("Cards in deck = " + deckleft);
			printHand(players[asker]);
			System.out.println("You have " + players[asker].books + " books.");
			System.out.println("Who do you want to ask for a card?");
			for(int i= 0; i< asker; i++){
				System.out.println(players[i].name + ": " + i);
			}
			for(int j= asker+1; j< players.length; j++){
					System.out.println(players[j].name + ": " + j);			
			}
			
			boolean validPlayer = false;
			while (!validPlayer) {
				try {
					asked = s.nextInt();
					s.nextLine();
					if (asked >= 0 && asked <= players.length - 1) {
						if (asked == asker) {
							System.out.println("You can't ask yourself!\nWho do you want to ask?");
						} else {
							validPlayer = true;
							count++;
						}
					} else 
						System.out.println("Not a valid player!");
					
				} catch (InputMismatchException e) {
					System.out.println("Not a valid player!\nWho do you want to ask?");
					s.nextLine();
				}
			}
			
			boolean validCard = false;
			while (!validCard) {
				System.out.println("\nWhat card do you want to ask "+ players[asked].name +" for?");
				try {
					card = s.nextInt();
					if (!isValidCard(players[asker], card)) {
						System.out.println("Not a valid card!");
					} else {
						validCard = true;
					}
				} catch (InputMismatchException e) {
					System.out.println("Not a valid card!");
					s.nextLine();
				}
			}
			
			if(count<2)
				temp = asked;

			if (players[asked].hand[card - 1] == 0) {
				System.out.println("Go fish!");
				deckleft--;
				int fish = players[asker].drawCard(deck);
				if (fish == card) {
					System.out.println(" You drew a " + fish);
					players[asker].createBook();
					if (players[asker].numCards > 0) {
						System.out.println("You get to go again!");
						turn(asker);
					} else {
						break;
					}
				} else {
					//This switches turn to first person asked
					System.out.println(" You drew a " + fish);
					asker = temp;
					turn(asker);
				}
			} else {
				players[asked].transferCards(players[asker], card);
				players[asker].createBook();
				if (players[asker].numCards == 0) {
					winner();
					break;
				}
				if (players[asked].numCards == 0) {
					winner();
					break;
				}
			}
				
		} while(deckleft > 0);      //while there are cards left in the deck
		winner();
	}
	
	public static void main(String[] args) {
		GoFish game = new GoFish();
		game.turn(0);
	}
}
