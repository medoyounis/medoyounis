//Mohammed Younis && Daniel Linn
public class Player {

	protected String name;
	protected Card[] startingHand = new Card[52];
	public int[] hand = new int[13];     //transfering array of cards to array of integers
	protected int books;
	protected int numCards = 0;
	
	public int drawCard(Deck d) { //drawing method 
		Card draw = d.draw();
		hand[draw.getRank()-1]++;
		createBook();
		numCards++;
		return draw.getRank();
	}
		
	
	public void createBook() { // to check for books
		for(int i=0; i<hand.length; i++) {
			if(hand[i] == 4) {
				books++;
				hand[i] = 0;
				numCards =numCards-4;
			}
		}
	}
	
	public void transferCards(Player p,int c) {		 //method to transfer cards
		p.hand[c-1] += hand[c-1];

		numCards = numCards - hand[c-1];
		p.numCards += /*p.numCards +*/ hand[c-1];
		hand[c-1] = 0;
	}
	
	public String toString() {
		return name;
	}
	
}
