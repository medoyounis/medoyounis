
public class Deck {
	
	private Card[] theCards = new Card[52]; // array of 52 Card objects
    private int topCard = 0;    // keeps track of the index of the top card

    // constructor
    public Deck()
    {
        // the array of Card objects contains a bunch of null references by default, so
        // we need to create some actual Card objects to place in there!
        int i = 0;
        for (int s = 0; s < 4; s++)
        {
            for (int r = 1; r <= 13; r++)
            {
                theCards[i] = new Card(r);    // create a new Card of each suit and rank
                i++;
            }
        }
    }

    // shuffles the deck by running the shuffle algorithm 10 times
    public void shuffle()
    {
        shuffle(10);
    }
    
    // shuffles the deck by running the shuffle algorithm n times
    public void shuffle(int n)
    {
        for (int j = 0; j < n; j++)
        {
            // swap the card at each index with the card at a randomly chosen index
            for (int i = 0; i < theCards.length; i++)
            {
                int rand = (int)(theCards.length*Math.random());    // pick a random index (0-51)
                
                // swap the cards at index i and rand
                Card temp = theCards[i];
                theCards[i] = theCards[rand];
                theCards[rand] = temp;
            }
        }
    }

    // "draws" the top card from the deck
    //  (we don't actually remove the card from the array -
    //   we just keep track of which index is currently
    //   the top)
    public Card draw()
    {
        if (topCard <= theCards.length)
            return theCards[topCard++]; // this returns theCards[topCard] first, then increments topCard
        else
        {
            System.out.println("Deck is out of cards!");
            return null;    // needed since the method still needs to return something
        }
    }
    
    // toString method - this just goes through the deck and
    //  calls toString on each individual card, and combines
    //  the results into a single string
    public String toString()
    {
        String toReturn = "";
        for (int i = 0; i < theCards.length; i++)
            toReturn += theCards[i] + "\n"; // theCards[i].toString() is being implicitly called here
        return toReturn;
    }
    
    // test main
//    public static void main(String[] args)
//    {
//        Deck d = new Deck();
//        System.out.println(d);
//        d.shuffle();
//        System.out.println();
//        System.out.println(d);
//        
//        for (int i = 0; i < 53; i++)
//            System.out.println("drawing: " + d.draw());
//    }

}
