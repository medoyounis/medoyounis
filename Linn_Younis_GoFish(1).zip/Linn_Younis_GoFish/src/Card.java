//Mohammed Younis && Daniel Linn
public class Card {

	// private String suit;    // clubs, diamonds, hearts, or spades
	    private int rank;       // 2-10 = that rank, 11 = jack, 12 = queen, 13 = king, 14 = ace

	    // getter methods
//	    public String getSuit()
//	    {
//	        return suit;
//	    }

	    public int getRank() //getter
	    {
	        return rank;
	    }
	    
	    // constructor
	    public Card(int r)
	    {
	        //suit = s;
	        rank = r;
	    }

	    // toString method - returns the card in "rank of suit" format
	    public String toString()
	    {
	        String rankString = "" + rank;
	        switch (rank)
	        {
	            case 11:
	                rankString = "jack";
	                break;
	            case 12:
	                rankString = "queen";
	                break;
	            case 13:
	                rankString = "king";
	                break;
	            case 1:
	                rankString = "ace";
	                break;
	            default:
	                rankString = "" + rank;
	        }
	        return rankString;
	    }
	    
	    // test main
	    public static void main(String[] args)
	    {
	        // go through all ranks of spades
	        for (int r = 1; r <= 13; r++)
	        {
	            Card c = new Card(r);
	            System.out.println(c);
	        }
	    }
}
