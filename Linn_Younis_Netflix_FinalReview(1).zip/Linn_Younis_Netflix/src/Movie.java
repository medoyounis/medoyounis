/**
 * 
 * @author Daniel Linn & Mohammed Younis
 *
 */
public class Movie extends Media {

	public Movie(String t, String y, double r, String l) {
		super(t, y, r, l);
	}

	@Override
	public String toString() {
		String toReturn = super.toString();
		return toReturn.concat(" minutes");		
	}
}
