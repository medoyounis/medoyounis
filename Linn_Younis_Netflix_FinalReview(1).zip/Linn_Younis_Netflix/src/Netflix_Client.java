import java.io.File;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

/**
 * @author Daniel Linn & Mohammed Younis
 * 
 *
 */
public class Netflix_Client {
	public static ArrayList<Filter>  filterList = new ArrayList<>();
	public static ArrayList<Media> masterList = NetflixFileReader.createList(new File("NetflixUSA_Oct15_cleaned.txt"));
	//public static ArrayList<Media>  currentList = new ArrayList<>();
	static boolean end = false;
	
	
	public static void menu() {
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		
		while (!end) {
			ArrayList<Media>  currentList = new ArrayList<>();
			int selection;
			boolean validInput = false;
			try {
				System.out.println("\nPress 1 to add a filter\n2 to remove a filter\n3 to print to screen\n4 to end the program");
				selection = input.nextInt();
				input.nextLine();
				//Add filter
				if (selection == 1) {
					while (!validInput) {
						try {
							System.out.println("\nPlease choose a filter type:\n1 Genre\n2 Title\n3 Year\n4 Rating\n or enter 0 to go back.");
							int field = Integer.parseInt(input.nextLine());

							if (field >= 1 && field <= 4) {
								filterList.add(new Filter(field));
								for (int i = 0; i < masterList.size(); i++) {
									boolean validMedia = true;
									for (int j = 0; j < filterList.size(); j++) {
										if (filterList.get(j).isValid(masterList.get(i)) == false) {
											validMedia = false;
										}
									}
									if (validMedia)
										currentList.add(masterList.get(i));
								}
								validInput = !validInput;
							} else if (field == 0) {
								validInput = !validInput;
							} else {
								System.out.println("Your entry was not between 0 and 4");
							}
						} catch (NumberFormatException e) {
							System.out.println("Invalid input: field");
							input.nextLine();
						}
					}
					//remove filter
				} else if (selection == 2) {
					if(filterList.size() == 0) {
						System.out.println("There are no filters in use.");
					} else {
						while (!validInput) {
							int loop = 1;
							for (Iterator<Filter> iterator = filterList.iterator(); iterator.hasNext();) {
								Filter filter = (Filter) iterator.next();
								System.out.println("Filter " + loop + ": " + filter);
								loop++;
							}
							System.out.println(
									"Type the number of the filter would you like to remove. Or enter 0 to go back.");
							try {
								int remove = input.nextInt();
								input.nextLine();
								if (remove > 0 && remove <= filterList.size()) {
									System.out.println("Succesfully removed: \"" + filterList.remove(remove - 1) + "\" filter");
									validInput = !validInput;
								} else if (remove == 0) {
									validInput = !validInput;
								} else {
									throw new InputMismatchException();
								}
								
								if (!filterList.isEmpty()) {
									for (int i = 0; i < masterList.size(); i++) {
										boolean validMedia = false;
										for (int j = 0; j < filterList.size(); j++) {
											if (filterList.get(j).isValid(masterList.get(i)) == true) {
												validMedia = !validMedia;
											}
										}
										if (validMedia)
											currentList.add(masterList.get(i));
									} 
								} else {
									currentList.addAll(masterList);
								}
	
							} catch (InputMismatchException e) {
								input.nextLine();
								System.out.println("Bad input. Try again");
							}
						}
					}
					//print the list with filters applied again
				} else if (selection == 3) {
					for (int i = 0; i < masterList.size(); i++) {
						boolean validMedia = false;
						for (int j = 0; j < filterList.size(); j++) {
							if (filterList.get(j).isValid(masterList.get(i)) == true) {
								validMedia = !validMedia;
							}
						}
						if (validMedia)
							currentList.add(masterList.get(i));
					}
					
					validInput = !validInput;
					//exit the program
				} else if (selection == 4) {
					end = !end;
					break;
				} else {
					System.out.println("Try again: selection");
					input.nextLine();
				}

				for (Iterator<Media> iterator = currentList.iterator(); iterator.hasNext();) {
					Media media = (Media) iterator.next();
					System.out.println(media);
				}
				if (currentList.size() > 0) {
					System.out.println("\nThe size of the list is: " + currentList.size());
				}

			} catch (InputMismatchException e) {
				System.out.println("Try again: options");
				input.nextLine();
			}
		}
	}
		
	public static void main(String[] args) {
		System.out.println("\nThe list has "+masterList.size()+" items");
		menu();
	}

}
