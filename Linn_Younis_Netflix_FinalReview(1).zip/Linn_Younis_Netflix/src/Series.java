/**
 * 
 * @author Daniel Linn & Mohammed Younis
 *
 */
public class Series extends Media {

	private String type;

	public Series(String t, String y, double r, String l, String ty) {
		super(t, y, r, l);
		this.type = ty;
	}
	
	@Override
	public String toString() {
		String toReturn = super.toString();
		return toReturn.concat(" "+type);	
	}

}
