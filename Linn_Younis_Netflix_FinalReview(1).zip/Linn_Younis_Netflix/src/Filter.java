import java.util.InputMismatchException;
import java.util.Scanner;

public class Filter {
	
	private String target;
	private int filterType;

	/**
	 * @author Daniel Linn & Mohammed Younis
	 * @param field value 1 for Genre, 2 for Title, 3 for Year, 4 for Rating
	 * 
	 */
	public Filter(int field) {
		filterType = field;
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		int selection;
		boolean correctInput = false;
		switch (field) {
		
		//genre
		case 1:
			while (!correctInput) {
				try {
					System.out.println("Select 1 for series or 2 for movies");
					selection = input.nextInt();
					if(selection == 1) {
						correctInput = !correctInput;
						target = "series";
					} else if(selection == 2) {
						correctInput = !correctInput;
						target = "movies";
					} else {
						System.out.println("Try again. Number not 1 or 2");
					}
				} catch (NumberFormatException e) {
					System.out.println("Try again.");
					input.nextLine();
				} catch (InputMismatchException e) {
					System.out.println("Try again.");
					input.nextLine();
				}
			}
			break;
		
		//title
		case 2:
			while (!correctInput) {
				try {
					System.out.println("Select 1 for exact match or 2 for partial match");
					selection = input.nextInt();
					if(selection == 1) {
						input.nextLine();
						System.out.println("Please enter the exact title");						
						correctInput = !correctInput;
						target = input.nextLine().toLowerCase();
					} else if(selection == 2) {
						input.nextLine();
						System.out.println("Please enter the keyword");
						correctInput = !correctInput;
						target = input.nextLine().toLowerCase();
						filterType = 5;
					} else {
						System.out.println("Try again. Number not 1 or 2");
					}
				} catch (NumberFormatException e) {
					System.out.println("Try again.");
					input.nextLine();
				} catch (InputMismatchException e) {
					System.out.println("Try again.");
					input.nextLine();
				}
			}
			break;
		
		//year
		case 3:
			while (!correctInput) {
				try {
					System.out.println("Select 1 for greater than or 2 for less than");
					selection = input.nextInt();
					if(selection == 1) {
						System.out.println("What year do you wish to compare against?: ");
						int year = input.nextInt();
						target = "> " + year;
						correctInput = !correctInput;
					} else if(selection == 2) {
						System.out.println("What year do you wish to compare against?: ");
						int year = input.nextInt();
						target = "< " + year;
						correctInput = !correctInput;
					} else {
						System.out.println("Try again. Number not 1 or 2");
					}
				} catch (NumberFormatException e) {
					System.out.println("Try again.");
					input.nextLine();
				} catch (InputMismatchException e) {
					System.out.println("Try again.");
					input.nextLine();
				}
			}
			break;
			
		//rating
		case 4:
			while (!correctInput) {
				try {
					System.out.println("Select 1 for greater than or 2 for less than");
					selection = Integer.parseInt(input.nextLine());
					if(selection == 1) {
						System.out.println("What rating do you wish to compare against?: ");
						double rating = input.nextDouble();
						target = "> " + rating;
						correctInput = !correctInput;
					} else if(selection == 2) {
						System.out.println("What rating do you wish to compare against?: ");
						double rating = input.nextDouble();
						target = "< " + rating;
						correctInput = !correctInput;
					} else {
						System.out.println("Try again. Number not 1 or 2");
					}
				} catch (NumberFormatException e) {
					System.out.println("Try again.");
					input.nextLine();
				} catch (InputMismatchException e) {
					System.out.println("Try again.");
					input.nextLine();
				}
			}
			break;
		
		default:
			System.out.println("Not a valid input of 1, 2, 3, or 4");
			System.exit(1);
			break;
		}	
	}
	
	/**
	 * 
	 * @param mediaEntry The Media item to compare against the target of the filter.
	 * @return return true if the Media item meets the criteria of the Filter.
	 */
	public boolean isValid(Media mediaEntry) {
		switch (filterType) {
		
		//genre
		case 1:
			if(target == "series" && mediaEntry instanceof Series)
				return true;
			else if(target == "movies" && mediaEntry instanceof Movie)
				return true;
			else
				return false;
		// exact title
		case 2:
			if(target.compareTo(mediaEntry.title.toLowerCase()) == 0)
				return true;
			else
				return false;
		//year
		case 3:
			String[] y = target.split(" ");
			
			if (mediaEntry instanceof Movie) {
				if (y[0].compareTo("<") == 0 && Integer.parseInt(y[1]) >= Integer.parseInt(mediaEntry.year)) {
					return true;
				} else if (y[0].compareTo(">") == 0 && Integer.parseInt(y[1]) <= Integer.parseInt(mediaEntry.year)) {
					return true;
				} else {
					return false;
				} 
			} else {
				if (y[0].compareTo("<") == 0 && Integer.parseInt(y[1]) >= Integer.parseInt(mediaEntry.year.substring(0, 4))) {
					return true;
				} else if (y[0].compareTo(">") == 0 && Integer.parseInt(y[1]) <= Integer.parseInt(mediaEntry.year.substring(0, 4))) {
					return true;
				} else {
					return false;
				} 
			}
		//rating
		case 4:
			String[] r = target.split(" ");
			if(r[0].compareTo("<") == 0 && Double.parseDouble(r[1]) >= mediaEntry.rating) {
				return true;
			} else if (r[0].compareTo(">") == 0 && Double.parseDouble(r[1]) <= mediaEntry.rating) {
				return true;
			} else {
				return false;
			}
			
		case 5:
			if(mediaEntry.title.toLowerCase().contains(target))
				return true;
			else
				return false;
			
		default:
			System.out.println("Error: filter target not between 1 and 4");
			return false;
		}
	}
	
	public String toString() {
		return target;
	}
	

}
