import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

/**
 * 
 * @author Daniel Linn & Mohammed Younis
 *
 */
public class NetflixFileReader {
	
	protected static ArrayList<Media> createList(File f) {
		ArrayList<Media> masterList = new ArrayList<>();
		Scanner read = null;
		int p =0;
		boolean loaded = false;
		try {
			read = new Scanner(new FileReader(f));
			loaded = !loaded;
		} catch (FileNotFoundException e) {
			System.out.println("No file found!");
		}

		if(loaded) {
			while(read.hasNextLine()) {
				String line = read.nextLine();
				//The line parsed is a movie
				if(line.charAt(line.length()-1) == 'm' || line.charAt(line.length()-1) == 'r' || line.charAt(line.length()-1) == ',') {
					int endIndex = Integer.MAX_VALUE;
					String year = "";
					double rating = 0;
					String length = "";
					//get the year
					for(int i=0; i<line.length(); i++) {
						if(line.charAt(i) == '(') {
							endIndex = i;
							year = line.substring(i+1, i+5);
							if(year.contains("|")) {
								year = "0";
							}
						}
						//get the rating
						if(line.charAt(i) == '|') {
							String r = line.substring(i, line.length());
							if( r.length() <= 5) {
								rating = 0;
							} else if(r.charAt(5) == '.') {
								rating = Double.parseDouble(r.substring(4,7));
							} else if(r.contains("stars,")) {
								rating = Double.parseDouble(r.substring(4,5));
							} else {
								rating = 0;
							}
							//String r = line.substring(i+4, i+7);
						}
						//get length
						if(i > endIndex && line.charAt(i) == ',') {
							String l = line.substring(i+1, line.length());
							if(l.contains("hr") && l.contains("m")) {
								l = l.replace("hr", "");
								l = l.replaceAll("m", "");
								l = l.trim();
								String[] arr = l.split("\\s");
								int time = Integer.parseInt(arr[0])*60;
								time += Integer.parseInt(arr[1]);
								length = String.valueOf(time);
							}else if(l.contains("hr")) {
								l = l.replace("hr", "");
								l = l.trim();
								String[] arr = l.split("\\s");
								int time = Integer.parseInt(arr[0])*60;
								length = String.valueOf(time);
							} else if (l.contains("m")) {
								l = l.replaceAll("m", "");
								l=l.trim();
								String[] arr = l.split("\\s");
								int time = Integer.parseInt(arr[0]);
								length = String.valueOf(time);
							} else {
								length = "0";
							}
						}   
					}
					//get the title
					String title = line.substring(0, endIndex).trim();
					masterList.add(new Movie(title, year, rating, length));
				} else if(line.charAt(line.length()-1) == 's' || line.charAt(line.length()-1) == 'n' ||
						line.charAt(line.length()-1) == 'e' || line.charAt(line.length()-1) == 't' ||
						line.charAt(line.length()-1) == 'l') {
					int endIndex = Integer.MAX_VALUE;
					int end=0;
					String year = "";
					double rating = 0;
					String length = "";
					String type = "";
					for(int i=0; i<line.length(); i++) {
						if(line.charAt(i) == '(') {
							endIndex = i;
						}
						if(line.charAt(i) == ')') {
							end = i;
							year = line.substring(endIndex+1, end);
						}

						if(line.charAt(i) == '|') {
							String r = line.substring(i+4, i+7);
							if(r.charAt(1) == '.') {
								rating = Double.parseDouble(r);
							} else if(line.charAt(i+6) == 's' || line.charAt(i+8) == 's') {
								rating = Double.parseDouble(r.substring(0,1));
							} else {
								rating = 0;
							}
						} 
						if(i > endIndex && line.charAt(i) == ',') {
							String l = line.substring(i+1, line.length());
							if(l.contains("Seasons")) {
								type = "Seasons";
								l = l.replace("Seasons", "");
								String[] arr = l.split("\\s");
								int time = Integer.parseInt(arr[1]);
								length = String.valueOf(time);
							}                             

							if(l.contains("Season")) {
								type = "Season";
								l = l.replace("Season", "");
								String[] arr = l.split("\\s");
								int time = Integer.parseInt(arr[1]); 
								length = String.valueOf(time);
							}  
							if(l.contains("Volumes")) {
								type = "Volumes";
								l = l.replace("Volumes", "");
								String[] arr = l.split("\\s");
								int time = Integer.parseInt(arr[1]);
								length = String.valueOf(time);
							}
							if(l.contains("Volume")) {
								type = "Volume";
								l = l.replace("Volume", "");
								String[] arr = l.split("\\s");
								int time = Integer.parseInt(arr[1]);
								length = String.valueOf(time);
							} 

							if(l.contains("Parts")) {
								type = "Parts";
								l = l.replace("Parts", "");								
								String[] arr = l.split("\\s");
								int time = Integer.parseInt(arr[1]);
								length = String.valueOf(time);
							}
							
							if(l.contains("Part")) {
								type = "Part";
								l = l.replace("Part", "");							
								String[] arr = l.split("\\s");
								int time = Integer.parseInt(arr[1]);
								length = String.valueOf(time);
							}
							
							if(l.contains("Collections")) {
								type = "Collections";
								l = l.replace("Collections", "");								
								String[] arr = l.split("\\s");
								int time = Integer.parseInt(arr[1]);
								length = String.valueOf(time);
							}
							
							if(l.contains("Special")) {
								type = "Special";
								l = l.replace("Special", "");								
								String[] arr = l.split("\\s");
								int time = Integer.parseInt(arr[1]);
								length = String.valueOf(time);
							
							}
						}  
					}
					String title = line.substring(0, endIndex).trim();
					masterList.add(new Series(title, year, rating, length, type));

				} else {
					System.out.println("Something is very wrong.");
					System.exit(1);
				}//end if
				System.out.println(masterList.get(p).toString());
				p++;
			}//end method
		}
		return masterList;
	}

	//test main
	public static void main(String[] args) 
	{
		createList(new File("NetflixUSA_Oct15_cleaned.txt"));

	}//end main

}//end class
