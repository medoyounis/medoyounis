
/**
 * 
 * @author Daniel Linn & Mohammed Younis
 *
 */
public abstract class Media {
		
		String title;
		String year;
		double rating;
		String length;
	

	public Media(String t, String y, double r, String l) {
		title = t;
		year = y;
		rating = r;
		length = l;
	}
	
	public String toString() {
		return title + " (" + year + ") rating: " + rating + " Length: " + length;
	}

}
